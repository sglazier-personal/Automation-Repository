#!/usr/local/bin/bash

### Import Shared Functions ###
source $PWD/functions.sh

### Property Files ###
GLB_PROPS=$PWD/properties/global.properties
CON_PROPS=$PWD/properties/acme-nd.properties
LISTENER_PROPERTIES=("$PWD/properties/acme-nd-admin-listener.properties" "$PWD/properties/acme-nd-https-listener.properties")

### Init Environment ###
f_init

### Executing Recipes ###

echo "**** Create ND Container ****"
f_executeRecipe "acme-nd-create.json"

echo "**** Add Listeners ****"
f_addContainerListeners

echo "**** Please Wait... ****"
sleep 5

echo "**** Shutdown Container ****"
f_shutdown "$CONTAINER_NAME"

echo "**** Please Wait... ****"
sleep 5

echo "**** Start Container ****"
f_start "$CONTAINER_NAME"

echo "**** Please Wait... ****"
sleep 20

#### Install Remaining Features ####
echo "**** Installing Remaining Features ****"
f_executeRecipe "acme-nd-install.json"

echo "**** Please Wait... ****"
sleep 5

#### Register Container ####
echo "**** Registering Container ****"
f_executeRecipe "register-container.json"

#### Final Restart ####
echo "**** Registering Container ****"
f_executeRecipe "restart.json"

echo "**** CONTAINER BUILD COMPLETED ****"
