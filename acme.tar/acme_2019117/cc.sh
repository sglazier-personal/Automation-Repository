#!/bin/bash
#
# This scritp should be called from init with proper parameters
#
# Usage:
#    cc.sh {start|stop|restart|status} {all|<instance name>}
#       start   - script will try to start container(s)
#       stop    - script will try to stop the container(s)
#       restart - script will shutdown and start up the container(s)
#       status  - script will print the status of containers(s)
#       blogs   - script will backup container(s) log
#
#       all     - script will invoke operation on all container on the box except the 'configurator'
#       <instance name> - script will invoke operation on container named <instance name>
#
# Dependancies:
#    $AKANA_BASE - properly defined Akana base installation folder
#
# Version: v1.0
# Akana ICE 

AKANA_BASE=/opt/akana_sw/AAP2019117/

container_names=()
akana_teammate=$(whoami)
cc_log_file=$AKANA_BASE/cc.log

timestamp() {
  date +"%d.%m.%Y - %T"
}

log() {
   echo "$@" | tee -a $cc_log_file
}

log '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>'
log "Command center called at $(timestamp) by $akana_teammate"


if [[ "$#" -ne 2 ]]; then
    log "Usage: $0 {start|stop|restart|status} {all|<instance name>}"
    exit 2
fi

case "$2" in
   all)
     for instance in $AKANA_BASE/instances/*
       do
         if [ ${instance##*/} = "configurator" ]; then
           continue
         fi
        container_names+=(${instance##*/})
     done
   ;;
   *)
      if [[ ! -d $AKANA_BASE/instances/$2 ]]; then
         log "There is NO '$2' container on this box!!!"
         exit 2
      else
         container_names+=($2)
      fi
esac

start() {
  log "Akana start initiated..."
  for instance in "${container_names[@]}"; do
     local PIDFILE=$AKANA_BASE/instances/$instance/java.pid
     if [ -f $PIDFILE ] && kill -0 $(cat $PIDFILE) 2>/dev/null; then
         log '   Container '$instance' already running'
         continue
     fi
     if [ -f $PIDFILE ]; then
        rm $PIDFILE
     fi
     log -n '   Starting container '$instance'…'
     cd $AKANA_BASE/bin
     $AKANA_BASE/bin/startup.sh $instance -bg -Xmx4096M >/dev/null
     log ' started'
  done
}

stop() {
  log "Akana shutdown initiated..."
  for instance in "${container_names[@]}"; do
     local PIDFILE=$AKANA_BASE/instances/$instance/java.pid
     if [ -f $PIDFILE ] && kill -0 $(cat $PIDFILE) 2>/dev/null; then
         log -n '   Stopping container '$instance'…'
         cd $AKANA_BASE/bin
         $AKANA_BASE/bin/shutdown.sh $instance &1>/dev/null 2>&1
         log ' stopped'
     else
         log '   Container '$instance' is already stopped'
     fi
  done
}

status() {
  log "Akana status check"
  for instance in "${container_names[@]}"; do
     local PIDFILE=$AKANA_BASE/instances/$instance/java.pid
     if [ -f $PIDFILE ] && kill -0 $(cat $PIDFILE) 2>/dev/null; then
         log '   Container '$instance' running'
     else
         log '   Container '$instance' NOT running'
     fi
  done
}

blog() {
  log "Akana log backup"
  for instance in "${container_names[@]}"; do
     local PIDFILE=$AKANA_BASE/instances/$instance/java.pid
     if [ -f $PIDFILE ] && kill -0 $(cat $PIDFILE) 2>/dev/null; then
         log '   Container '$instance' running. Can not backup files on running container'
     else
         $AKANA_ICE/scripts/backmylogs.sh $instance
     fi
  done
}

case "$1" in
  start)
    start
    ;;
  stop)
    stop
    ;;
  restart)
    log "Restarting..."
    stop
    sleep 2
    start
    ;;
  status)
    status
    ;;
  blog)
    blog
    ;;
  *)
    log "Usage: $0 {start|stop|restart|status|blog} {all|<instance name>}"
    exit 2
esac

log -e '<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n\n'

