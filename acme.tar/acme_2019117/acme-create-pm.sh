#!/usr/local/bin/bash

### Import Shared Functions ###
source $PWD/functions.sh

### Property Files ###
INS_PROPS="$PWD/properties/installation-files.properties"
GLB_PROPS="$PWD/properties/global.properties"
CON_PROPS="$PWD/properties/acme-pm.properties"
# Property Array (Seperate with space)
LISTENER_PROPERTIES=("$PWD/properties/acme-pm-admin-listener-9909.properties" "$PWD/properties/acme-pm-listener-9900.properties")

### Init Environment ###
f_init

### Executing Recipes ###

echo "**** Create PM Container ****"
f_executeRecipe "acme-pm-create.json"

echo "**** Please Wait... ****"
sleep 5

echo "**** Add Container Listener(s) ****"
f_addContainerListeners

echo "**** Shutdown Container ****"
f_shutdown "$CONTAINER_NAME"

echo "**** Please Wait... ****"
sleep 5

echo "**** Start Container ****"
f_start "$CONTAINER_NAME"

echo "**** Please Wait... ****"
sleep 60

echo "**** Complete Installation & Provisioning ****"
f_executeRecipe "acme-pm-install-provision.json"

echo "**** Updating WSMEX ****"
f_executeRecipe "acme-pm-wsmex.json"

echo "**** Please Wait... ****"
sleep 5

echo "**** Add Container to Cluster ****"
f_executeRecipe "add-to-local-cluster.json"

echo "**** Please Wait... ****"
sleep 5

echo "**** Final provisioning ****"
f_executeRecipe "acme-pm-provision-task.json"

echo "**** Please Wait... ****"
sleep 10

echo "**** Final restart ****"
f_executeRecipe "restart.json"

echo "**** CONTAINER BUILD COMPLETED ****"