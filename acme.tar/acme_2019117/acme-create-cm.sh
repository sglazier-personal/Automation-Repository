#!/usr/local/bin/bash

### Import Shared Functions ###
source $PWD/functions.sh

### Property Files ###
INS_PROPS="$PWD/properties/installation-files.properties"
GLB_PROPS="$PWD/properties/global.properties"
CON_PROPS="$PWD/properties/acme-cm.properties"
# Property Array (Seperate with space)
LISTENER_PROPERTIES=("$PWD/properties/acme-cm-admin-listener-9919.properties" "$PWD/properties/acme-cm-listener-9910.properties")
TENANT_PROPERTIES=("$PWD/properties/acme-cm-tenant-prod.properties")

### Init Environment ###
f_init

#### Executing Recipes ####

echo "**** Create Container ****"
f_executeRecipe "acme-cm-create.json"

echo "**** Please Wait... ****"
sleep 10

#### Add Container Listeners ####
f_addContainerListeners

echo "**** Please Wait... ****"
sleep 5

echo "**** Shutdown Container ****"
f_shutdown "$CONTAINER_NAME"

echo "**** Please Wait... ****"
sleep 5

echo "**** Start Container ****"
f_start "$CONTAINER_NAME"

echo "**** Please Wait... ****"
sleep 60

echo "**** Complete Installation & Provisioning ****"
f_executeRecipe "acme-cm-install-provision.json"

echo "**** Creating Tenants ****"
f_createTenants "acme-cm-tenant.json"

echo "**** Please Wait... ****"
sleep 5

echo "**** Add Container to Cluster ****"
f_executeRecipe "add-to-local-cluster.json"

echo "**** Final provisioning ****"
f_executeRecipe "cm-provision-task.json"

echo "**** Please Wait... ****"
sleep 10

echo "**** Final restart ****"
f_executeRecipe "restart.json"

echo "**** CONTAINER BUILD COMPLETED ****"