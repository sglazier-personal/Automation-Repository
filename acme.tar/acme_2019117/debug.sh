# PM
source $PWD/functions.sh && \
export GLB_PROPS=$PWD/properties/global.properties && \
export CON_PROPS=$PWD/properties/acme-pm.properties && \
export INS_PROPS=$PWD/properties/installation-files.properties && \
export LISTENER_PROPERTIES=("$PWD/properties/acme-pm-listener-9900.properties") && \
f_setupEnvProps $GLB_PROPS && \
f_setupEnvProps $CON_PROPS && \
export CONTAINER_NAME=pm2019117-20200506104127

# ND
source $PWD/functions.sh && \
export GLB_PROPS=$PWD/properties/global.properties && \
export CON_PROPS=$PWD/properties/acme-nd.properties && \
export INS_PROPS=$PWD/properties/installation-files.properties && \
export LISTENER_PROPERTIES=("$PWD/properties/acme-nd-listener-9915.properties") && \
f_setupEnvProps $GLB_PROPS && \
f_setupEnvProps $CON_PROPS && \
export CONTAINER_NAME=nd2019117-20200507163523

# CM
source $PWD/functions.sh && \
export GLB_PROPS=$PWD/properties/global.properties && \
export CON_PROPS=$PWD/properties/acme-cm.properties && \
export INS_PROPS=$PWD/properties/installation-files.properties && \
export TENANT_PROPERTIES=("$PWD/properties/acme-cm-tenant-prod.properties") && \
export LISTENER_PROPERTIES=("$PWD/properties/acme-cm-listener-9910.properties") && \
f_setupEnvProps $GLB_PROPS && \
f_setupEnvProps $CON_PROPS && \
export CONTAINER_NAME=cm2019117-20200506185557

