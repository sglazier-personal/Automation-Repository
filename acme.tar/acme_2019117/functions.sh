#!/bin/bash

### Init Environment ###
function f_init {
    ### Setup global variables ###
    echo "**** Setting up global variables from $GLB_PROPS ****"
    f_setupEnvProps "$GLB_PROPS"
    ### Setup container variables ###
    echo "**** Setting up container variables from $CON_PROPS ****"
    f_setupEnvProps "$CON_PROPS"
    ### Save all env variables ###
    f_env_save
    ### Check if we need to extract the installation files ###
    echo "**** Checking if we need to extract installation files ****"
    f_checkExtraction
    ### Backup existing recipes and copy custom recipes ###
    echo "**** Prepping recipes ****"
    f_prep_recipes
    ### Copy SLF Simple Logger Jar to lib/scripts/ directory
    echo "**** Copy SLF4J Logger jar file ****"
    f_copyLoggerImpl
    ### If self-signed certs are being used we need to perform some additional actions ###
    echo "**** Checking if we need to generate self-signed certs ****"
    f_generateSelfSignedCerts
    ### Init Completed ###
    echo "**** Environment Init Completed ****"
}
### Setup ENV ###
function f_setupEnvProps() {
    source <(awk -F= '$2' $1 | grep -v ^'#'| sed -E -n 's/[^#]+/export &/ p')
}
### Save env ###
function f_env_save () {
    [ ! -d "$PWD/env" ] && mkdir -p "$PWD/env"
    env >> "$PWD/env/$CONTAINER_NAME.properties"
}
### Generate CSR ###
function f_generateCSR() {
    [ ! -d "$PWD/certs" ] && mkdir -p "$PWD/certs"
    echo "**** Generate Key and CSR ****"
    openssl req -nodes -newkey rsa:2048 -keyout "$PWD/certs/$CONTAINER_NAME.key" -out "$PWD/certs/$CONTAINER_NAME.csr" -subj "/C=US/ST=MN/L=Minnesota/O=Akana/OU=Akana Container/CN=$CONTAINER_NAME"
}
### Generate Certificate Based on CSR ###
function f_generateCertFromCSR() {
    echo "**** Generating Certificate from CSR $PWD/certs/$CONTAINER_NAME.csr ****"
    openssl x509 -req -in "$PWD/certs/$CONTAINER_NAME.csr" \
    -CA "$AUTOMATION_HOME/keys/acmerootca.cer" \
    -CAkey "$AUTOMATION_HOME/keys/acmerootca.pkcs8" -CAcreateserial \
    -out "$PWD/certs/$CONTAINER_NAME.crt" \
    -days 1825 -sha256 -extfile "$AUTOMATION_HOME/keys/acme.ext"
}
### Generate New Key And Cert ###
function f_generateKeyAndCert {
    [ ! -d "$PWD/certs" ] && mkdir -p "$PWD/certs"
    echo "**** Generating New Priv Key and Certificate ****"
    openssl req -sha256 -new -x509 -nodes -out "$PWD/certs/$CONTAINER_NAME.crt" \
    -keyout "$PWD/certs/$CONTAINER_NAME.key" -days 3650 \
    -subj "/C=US/ST=MN/L=Minnesota/O=Akana/OU=Akana Container/CN=$CONTAINER_NAME"
    ### Add certificate (without key) to keystore ###
    f_import_cert "$CONTAINER_NAME-cert" "$PWD/certs/$CONTAINER_NAME.crt"
}
### Convert Certificate and Priv Key to p12 ###
function f_convertCertAndKey() {
    echo "**** Converting cert and key to p12 bundle ****"
    openssl pkcs12 -export -in "$PWD/certs/$CONTAINER_NAME.crt" \
    -inkey "$PWD/certs/$CONTAINER_NAME.key" -name "$CONTAINER_NAME" \
    -out "$PWD/certs/$CONTAINER_NAME.p12" \
    -passout pass:"$CONTAINER_NAME"
}
### Import p12 bundle to keystore ###
function f_importp12() {
    echo "**** Importing $CONTAINER_NAME.p12 to $BOOTSTRAP_KEYSTORE"
    
    KEYSTORE=$(echo "$BOOTSTRAP_KEYSTORE" | sed "s:file\://::g")
    KEYSTORE_PASSWORD=$($DECRYPT_CMD "$BOOTSTRAP_KEYSTORE_PASSWORD")

    keytool -noprompt -importkeystore -deststorepass "$KEYSTORE_PASSWORD" \
    -destkeystore "$KEYSTORE" -srckeystore "$PWD/certs/$CONTAINER_NAME.p12" \
    -srcstorepass "$CONTAINER_NAME" \
    -srcstoretype PKCS12
}
### Generate Self-Signed Certs ###
function f_generateSelfSignedCerts() {
    if [ "$SELF_SIGNED_CERTS" == "true" ]
    then
        #### Generate key and Cert ####
        f_generateKeyAndCert
        #### Convert Certificate and Priv Key to p12 ####
        f_convertCertAndKey
        #### Import keypair into keystore ####
        f_importp12
        #### Add Public Key / Listener Cert to keystore ####

    else
        echo "**** Not Generating Self-Signed Certs ****"
    fi
}
### Extract Property ###
# arg1=[PROPERTY] arg2=[PROPERTY FILE]
function f_prop() {
    grep -w "$1" "$2" | cut -d'=' -f2
}
### Backup / Copy Recipes ####
function f_prep_recipes() {
    echo "**** Creating backup file of existing recipes ****"
    [ ! -d "$AUTOMATION_HOME/backups" ] && mkdir -p "$AUTOMATION_HOME/backups"
    tar --create --gzip --file="$RECIPES_DESTDIR/$RECIPES_BACKUP_FILENAME" "$RECIPES_SRCDIR" && \
    cp recipes/*.json "$RECIPES_SRCDIR/"
}
### Generate Listener Self-Signed Cert ###
# arg1=[ALIAS] arg2=[KEYSTORE] arg3=[STOREPASS] arg4=[KEYPASS] arg5=[VALIDITY]
function f_generate_cert() {
    echo "**** Generating self-signed certificate for $1 ****"
    keytool -genkey -noprompt -keyalg RSA -keysize 2048 -alias "$1" \
    -dname "CN=$1, OU=Akana, O=Akana, L=, S=CA, C=US" -keystore "$2" \
    -storepass "$3" -keypass "$4" -validity "$5"
}
### Get SSL Certificate ###
# arg1=[HOST] arg2=[PORT] arg3=[FILENAME]
function f_get_cert() {
    echo "**** Get SSL certificate from server $1:$2 ****"
    openssl s_client -showcerts -connect "$1":"$2" -servername "$1"  \
    </dev/null | sed -ne '/-BEGIN CERTIFICATE-/,/-END CERTIFICATE-/p' > "$3"
}
### Import Certificate to Keystore ###
# arg1=[CERT_ALIAS] arg2=[FILENAME]
function f_import_cert() {
    ALIAS="$1"
    KEYSTORE_PASSWORD=$($DECRYPT_CMD "$BOOTSTRAP_KEYSTORE_PASSWORD")
    echo "**** Importing Certificate ($1) to Keystore ****"
    keytool -import -alias "$ALIAS" \
    -keystore "$(echo $BOOTSTRAP_KEYSTORE | sed "s:file\://::g")" \
    -file "$2" \
    -storepass "$KEYSTORE_PASSWORD" \
    -noprompt
}
### Generate Self-Signed Certs for all listeners ###
function f_generate_listener_certs() {
    for i in "${LISTENER_PROPERTIES[@]}"; do
        # Get Properties
        ALIAS=$(f_prop 'ALIAS' $i)
        KEYSTORE=$(f_prop 'KEYSTORE' $i)
        KEYSTORE_PASSWORD=$($DECRYPT_CMD $(f_prop 'KEYSTORE_PASSWORD' $i))
        KEY_PASSWORD=$($DECRYPT_CMD $(f_prop 'KEY_PASSWORD' $i))
        VALIDITY=3650
        # Call f_generate_cert()
        echo "**** Generating certificate for $ALIAS ****"
        f_generate_cert $ALIAS $KEYSTORE $KEYSTORE_PASSWORD $KEY_PASSWORD $VALIDITY
    done    
}
### Check if installation DIR exists and create if required ###
# arg1=[DIRECTORY]
function f_prepInstallationDir() {
    [ ! -d $1 ] && mkdir -p $1 && \
    echo "**** Installation Directory $1 Created ****"
}
### Extract FILE to DIRECTORY  ###
# arg1=[FILE] arg2=[TARGET DIRECTORY]
function f_extractInstallationFiles() {
    declare -A INSTALL_FILES
    # Read with:
    # IFS (Field Separator) =
    # -d (Record separator) newline
    # first field before separator as k (key)
    # second field after separator and reminder of record as v (value)
    while IFS='=' read -d $'\n' -r k v; do
        # Skip lines starting with sharp
        # or lines containing only space or empty lines
        [[ "$k" =~ ^([[:space:]]*|[[:space:]]*\#.*)$ ]] && continue
        # Store key value into assoc array
        INSTALL_FILES[$k]="$v"
        # stdin the properties file
    done < $INS_PROPS

    for i in "${INSTALL_FILES[@]}"; do
        echo "**** Extracting $i to $INSTALL_DIR"
        unzip -o $DEPLOY_ASSETS_DIR/$i -d $INSTALL_DIR
    done
}
### Copy SLF4J Logger Implementation ###
function f_copyLoggerImpl() {
    cp $INSTALL_DIR/lib/ext/slf4j-simple-*.jar $INSTALL_DIR/lib/script/
}
### Decrypt Value ###
# arg1=[VALUE TO DECRYPT]
function f_decrypt() {
    $DECRYPT_CMD $1
}
### Split Certificate Chain ###
# arg1=[CERTIFICATE FILE]
function f_splitCerts() {
    cat $1 | awk 'split_after==1{n++;split_after=0} /-----END CERTIFICATE-----/ {split_after=1} {print > "cert" n ".pem"}'
}
### Add Certificate to PM Trusted Certs ###
# arg1=[HOST] arg2=[PORT] arg3=[FILENAME FOR CERT]
function f_addTrustedCert() {
    HOST=$1
    PORT=$2
    FILENAME=$3
    PM_PASSWORD_DECRYPTED=$(f_decrypt "$PM_PASSWORD")
    PM_AUTH_B64=$(echo -n "$PM_ADMIN:$PM_PASSWORD_DECRYPTED" | base64)
    PM_AUTH="Authorization: Basic $PM_AUTH_B64"
    # Get SSL cert from server and save it to file
    f_get_cert "$HOST" "$PORT" "$FILENAME"
    # Split certificate chain into multiple files
    f_splitCerts "$FILENAME"
    echo "**** ADDING CERTIFICATES TO PM TRUSTSTORE ***"
    # Add each cert from the chain to PM Truststore
    for file in "$PWD"/*.pem
        do
        CERT_ALIAS=$(openssl x509 -noout -serial -in "$file" | sed "s:serial=::g")
        CERT_BASE64=$(openssl base64 -A -in "$file")
        # Make API Call to PM Trusted Cert Endpoint
        curl --insecure --location --request POST "$PM_TRUSTED_CERT_API" \
        --header 'Content-Type: application/json' \
        --header 'Accept: application/json' \
        --header ''"$PM_AUTH"'' \
        --data-raw '{
        "alias": "'$CERT_ALIAS'",
        "base64": "'$CERT_BASE64'"
        }'
        echo "**** Added $CERT_ALIAS to PM Truststore ****"
        rm "$file"
    done 
    rm "$FILENAME"
}
### Extract Installation Files ###
function f_checkExtraction() {
    if [ "$EXTRACT_INSTALLATION_FILES" == "true" ]
    then
        # Prep installation directory
        echo "**** Prepping Installation Directory ****"
        f_prepInstallationDir "$INSTALL_DIR"
        # Extract installation files
        echo "**** Extracting Installation Files ****"
        f_extractInstallationFiles
    else
        echo "**** Not Extracting Installation Files ****"
    fi
}
### Add Container Listeners ###
function f_addContainerListeners() {
    LISTENER_ADD_RECIPE="add-local-listener.json"
    for i in "${LISTENER_PROPERTIES[@]}"
    do
        echo "**** Add $i Listener **** "
        $AUTOMATION_CMD --props "$i" --recipe "$RECIPES_SRCDIR/$LISTENER_ADD_RECIPE"
        echo "**** Please Wait... ****"
        sleep 5
    done
}
### Update Container Listeners ###
function f_updateContainerListeners() {
    LISTENER_UPDATE_RECIPE="update-local-listener.json"
    for i in "${LISTENER_PROPERTIES[@]}"
    do
        echo "**** Update $i Listener **** "
        $AUTOMATION_CMD --props "$i" --recipe "$RECIPES_SRCDIR/$LISTENER_UPDATE_RECIPE"
        echo "**** Please Wait... ****"
        sleep 5
    done
}
### Create CM Tenants ###
function f_createTenants() {
    TENANT_RECIPE=$1
    TENANT_CONTEXT_RECIPE="tenant-context.json"
    for i in "${TENANT_PROPERTIES[@]}"
    do
        # Check if tenant needs to be created
        CREATE_TENANT=$(f_prop 'CREATE_TENANT' $i)
        export TENANT_CONTEXT_ROOT=$(f_prop 'TENANT_CONTEXT_ROOT' $i)
        if [ "$CREATE_TENANT" == "true" ]
            then
            echo "**** Add $i Tenant **** "
            $AUTOMATION_CMD --props "$i" --recipe "$RECIPES_SRCDIR"/"$TENANT_RECIPE"
            else
            echo "**** Not Creating Tenant for $i ****"
            $AUTOMATION_CMD --props "$i" --recipe "$RECIPES_SRCDIR"/"$TENANT_CONTEXT_RECIPE"
        fi
    done
}
### Shutdown Container ###
# arg1=[CONTAINER_NAME]
function f_shutdown() {
    echo "**** Shutting down $1 ****"
    $INSTALL_DIR/bin/shutdown.sh $1
}
### Start Container ###
# arg1=[CONTAINER_NAME]
function f_start() {
    echo "**** Starting $1 ****"
    $INSTALL_DIR/bin/startup.sh $1 -bg
}
### Execute Recipe ###
# arg1=[RECIPE]
function f_executeRecipe() {
    RECIPE=$1
    echo "**** Executing recipe $1 ****"
    $AUTOMATION_CMD --props "$CON_PROPS" --recipe "$RECIPES_SRCDIR/$RECIPE"
}
### Upload Certificate to PM Trusted Certs ###
# arg1=[CERT FILE]
function f_uploadCA() {
    FILENAME=$1
    PM_PASSWORD_DECRYPTED=$(f_decrypt "$PM_PASSWORD")
    PM_AUTH_B64=$(echo -n "$PM_ADMIN:$PM_PASSWORD_DECRYPTED" | base64)
    PM_AUTH="Authorization: Basic $PM_AUTH_B64"

    CERT_ALIAS=$(openssl x509 -noout -serial -in "$FILENAME" | sed "s:serial=::g")
    CERT_BASE64=$(openssl base64 -A -in "$FILENAME")
    # Make API Call to PM Trusted Cert Endpoint
    curl --insecure --location --request POST "$PM_TRUSTED_CERT_API" \
    --header 'Content-Type: application/json' \
    --header 'Accept: application/json' \
    --header ''"$PM_AUTH"'' \
    --data-raw '{
    "alias": "'$CERT_ALIAS'",
    "base64": "'$CERT_BASE64'"
    }'
    echo "**** Added $CERT_ALIAS to PM Truststore ****"
}