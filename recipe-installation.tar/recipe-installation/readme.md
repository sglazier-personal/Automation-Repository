## README for recipe installation of Akana

### Folder and file structure of this project:
- recipe folder: Contains all recipes and properties file
- shell-scripts folder: Contains all shell scripts required to complete installation

### Prior to running the installation shell scripts we need to make the following changes:

#### Setup JKS files:
- Create a .jks with private key/public cert pairing to be used for HTTPS listeners. In the example, this is isb.jks
- Create a .jks with the above certs imported as a trusted certs. In the example, this is isb-trust.jks

#### Update properties file:
- Review and modify all .properties file to match environment. 
- The items that need to be modified:
    - DB connection information
    - ES connection information
    - Mongo connection information
    - Container Details
    - PM admin user
    - Listener Details
    - Cluster Details
    - Truststore information
    - Tenant information for tenant.properties (this is a one time activity for a new install)
- All recipe and property files are zipped together in a "recipes.zip"

#### Update shell scripts:
- Update the variables at the top of each shell script with the correct information for your environment

### This is how I have my folder setup for installation
This can be done differently depending on desired setup and use-case. I have a single /automation folder that contains the following:
- All installation .zip
- All shell scripts
- The recipes.zip file

### Running the recipe installation
- Create the INSTALL_PATH directory
- Run the install-base.sh
    - This will unzip all the Akana installation files, recipes.zip, and other related install files to the INSTALL_PATH directory
- Run the create-api*.sh to create the respective container
    - This will call the recipes in the correct order and create the container.