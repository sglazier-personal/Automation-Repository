#!/bin/sh
INSTALL_PATH="/opt/akana/charter/esx-sb-10/2019.1.19"
PROPERTY_FILE="1_apiplatform.properties"
LISTENER_PROPERTY_FILE="1_apiplatform-https-listener.properties"
CONTAINER_NAME="charter_pm"
LOG_LEVEL="INFO"

echo "**** Create PM Container ****"
$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=$LOG_LEVEL -Dorg.slf4j.simpleLogger.logFile=01_pm_create.log -m akana.container --recipe $INSTALL_PATH/recipes/char-1apiplatform-mongo-create.json  --props $INSTALL_PATH/recipes/$PROPERTY_FILE --home $INSTALL_PATH
echo "**** PM CONTAINER CREATED SUCCESSFULLY ****"

echo "**** Add Local Listeners****"
$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=$LOG_LEVEL -Dorg.slf4j.simpleLogger.logFile=02a_pm_addlocallistener-https.log -m akana.container --recipe $INSTALL_PATH/recipes/add-local-listener.json  --props $INSTALL_PATH/recipes/$LISTENER_PROPERTY_FILE --home $INSTALL_PATH

sleep 5

$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=$LOG_LEVEL -Dorg.slf4j.simpleLogger.logFile=02b_pm_addlocallistener-admin.log -m akana.container --recipe $INSTALL_PATH/recipes/add-local-listener.json  --props $INSTALL_PATH/recipes/$PROPERTY_FILE --home $INSTALL_PATH
echo "**** Local Listeners Added Sucessfully****"

sleep 5

echo "**** Update Java Xmx=4096M"
sed -i 's/JAVA_OPTS="-Xmx2048M"/JAVA_OPTS="-Xmx4096M"/' $INSTALL_PATH/bin/startup.sh
echo "**** Updated Java Xmx=4096M"

echo "**** Complete Installation & Provisioning ****"
$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=$LOG_LEVEL -Dorg.slf4j.simpleLogger.logFile=03_pm_provision.log -m akana.container --recipe $INSTALL_PATH/recipes/char-2apiplatform-mongo-installprovision.json  --props $INSTALL_PATH/recipes/$PROPERTY_FILE --home $INSTALL_PATH
echo "**** INSTALLATION & PROVISIONING SUCCESSFULL ****"

sleep 30

echo "**** Add Container to Cluster ****"
$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=$LOG_LEVEL -Dorg.slf4j.simpleLogger.logFile=04_add-to-cluster.log -m akana.container --recipe $INSTALL_PATH/recipes/add-to-local-cluster.json  --props $INSTALL_PATH/recipes/$PROPERTY_FILE --home $INSTALL_PATH
echo "**** ADDED CONTAINER TO CLUSTER SUCCESSFULLY ****"

echo "**** Final provisioning ****"
$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=$LOG_LEVEL -Dorg.slf4j.simpleLogger.logFile=05_final-provisioning.log -m akana.container --recipe $INSTALL_PATH/recipes/char-3apiplatform-mongo-finalprovision.json  --props $INSTALL_PATH/recipes/$PROPERTY_FILE --home $INSTALL_PATH
echo "**** PROVISIONING SUCCESSFULL ****"

sleep 5

echo "**** Final restart ****"
$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=$LOG_LEVEL -Dorg.slf4j.simpleLogger.logFile=06_final-restart.log -m akana.container --recipe $INSTALL_PATH/recipes/restart.json  --props $INSTALL_PATH/recipes/$PROPERTY_FILE --home $INSTALL_PATH
echo "**** RESTARTED SUCCESSFULL ****"
