#!/bin/sh
INSTALL_PATH="/opt/akana/charter/`hostname -s`/2019"
SOURCE_PATH="/opt/akana/charter/automation"
AKANA_ZIP=("akana-platform-linux-jre-2019.1.10.zip" "akana-api-platform-2019.1.19.zip")

#unzip the akana-platform & akana-api-platform
for i in "${AKANA_ZIP[@]}"
do
	unzip $SOURCE_PATH/$i -d $INSTALL_PATH/
done

#unzip updated jce
unzip -j $SOURCE_PATH/jce_policy-8.zip -d $INSTALL_PATH/jre/lib/security/

#unzip custom recipes to INSTALL_PATH/recipes folder
unzip -o $SOURCE_PATH/recipes.zip -d $INSTALL_PATH/recipes/

#unzip binfiles to INSTALL_PATH/bin folder
unzip -o $SOURCE_PATH/binfiles.zip -d $INSTALL_PATH/bin

# Configure Logging
cp $INSTALL_PATH/recipes/simplelogger.properties $INSTALL_PATH/lib/script/
cp $INSTALL_PATH/lib/ext/slf4j-simple-1.7.19.jar $INSTALL_PATH/lib/script/

# remove Windoze files
rm $INSTALL_PATH/bin/*exe
rm $INSTALL_PATH/bin/*bat
