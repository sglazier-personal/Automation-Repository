#!/bin/sh
INSTALL_PATH="/opt/akana/charter/esx-sb-12/2019"
CONTAINER_NAME="nd-sb12"
CONTAINER_PROPERTY="3_apigateway-12.properties"
LISTENER_PROPERTIES=("3_apigateway-12-admin-listener.properties" "3_apigateway-12-https-listener.properties")

echo "**** Create ND Container ****"
$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=INFO -Dorg.slf4j.simpleLogger.logFile=01-nd_create.log -m akana.container --recipe $INSTALL_PATH/recipes/char-3apigateway-create.json  --props $INSTALL_PATH/recipes/$CONTAINER_PROPERTY --home $INSTALL_PATH
echo "**** ND CONTAINER CREATED SUCCESSFULLY ****"

sleep 10

for i in "${LISTENER_PROPERTIES[@]}"
do
	echo "**** Add $i Listener****"
	$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=INFO -Dorg.slf4j.simpleLogger.logFile=02-$i.log -m akana.container --recipe $INSTALL_PATH/recipes/add-local-listener.json  --props $INSTALL_PATH/recipes/$i --home $INSTALL_PATH
	sleep 5
done

echo "**** Listeners ADDED SUCCESSFULLY****"

sleep 5

echo "**** Update Java Xmx=4096M"
sed -i 's/JAVA_OPTS="-Xmx2048M"/JAVA_OPTS="-Xmx4096M"/' $INSTALL_PATH/bin/startup.sh
echo "**** Updated Java Xmx=4096M"

sleep 5

echo "**** Shutdown Container ****"
$INSTALL_PATH/bin/shutdown.sh $CONTAINER_NAME
echo "**** Container Shutdown Successfully ****"

sleep 10

echo "**** Start Container ****"
$INSTALL_PATH/bin/startup.sh $CONTAINER_NAME -bg
echo "**** Container Started Successfully ****"

sleep 60

echo "**** Register Container ****"
#$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=INFO -Dorg.slf4j.simpleLogger.logFile=04-nd_register.log -m akana.container --recipe $INSTALL_PATH/recipes/register-container.json  --props $INSTALL_PATH/recipes/$CONTAINER_PROPERTY --home $INSTALL_PATH
echo "**** CONTAINER REGISTERED SUCCESSFULLY ****"
echo "**** CONTAINER BUILT SUCCESSFULL ****"
