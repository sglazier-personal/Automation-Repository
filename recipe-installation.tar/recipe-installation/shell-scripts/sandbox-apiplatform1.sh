#!/bin/sh
INSTALL_PATH="/opt/akana/charter/esx-sb-10/2019.1.19"
PROPERTY_FILE="sandbox_cmpm_2019.properties"
LISTENER_PROPERTY_FILE="sandbox_cmpm_https_listener.properties"
CONTAINER_NAME="charter_pmcm"
LOG_LEVEL="TRACE"

echo "**** Create PM Container ****"
$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=$LOG_LEVEL -Dorg.slf4j.simpleLogger.logFile=01_pm_create.log -m akana.container --recipe $INSTALL_PATH/recipes/char-1apiplatform-mongo-create.json  --props $INSTALL_PATH/recipes/$PROPERTY_FILE --home $INSTALL_PATH
echo "**** PM CONTAINER CREATED SUCCESSFULLY ****"

echo "**** Shutdown Container ****"
$INSTALL_PATH/bin/shutdown.sh $CONTAINER_NAME
echo "**** Container Shutdown Successfully ****"

sleep 5

echo "**** Start Container ****"
$INSTALL_PATH/bin/startup.sh $CONTAINER_NAME -bg
echo "**** Container Started Successfully ****"

echo " "
echo "**** Manually check admin user and DB schemas then run create-apiplatform2.sh ****"
