#!/bin/sh
INSTALL_PATH="/opt/akana/charter/esx-sb-10/2019.1.18"
PROPERTY_FILE="1_apiplatform.properties"
LISTENER_PROPERTY_FILE="1_apiplatform-https-listener.properties"
CONTAINER_NAME="charter_pm"
LOG_LEVEL="TRACE"

###
###     Define Functions
###

createContainer() {
echo "**** Create PMCM Container ****"
##$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=$LOG_LEVEL -Dorg.slf4j.simpleLogger.logFile=01_pmcm_create.log -m akana.container --recipe $INSTALL_PATH/recipes/char-1apiplatform-mongo-create.json  --props $INSTALL_PATH/recipes/$PROPERTY_FILE --home $INSTALL_PATH
echo "**** PM CONTAINER CREATED SUCCESSFULLY ****"
}

#sleep 5

addListener1() {
echo "**** Add Local Listeners****"
##$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=$LOG_LEVEL -Dorg.slf4j.simpleLogger.logFile=02a_pmcm_addlocallistener-https.log -m akana.container --recipe $INSTALL_PATH/recipes/add-local-listener.json  --props $INSTALL_PATH/recipes/$LISTENER_PROPERTY_FILE --home $INSTALL_PATH
}

#sleep 5

addListener2() {
##$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=$LOG_LEVEL -Dorg.slf4j.simpleLogger.logFile=02b_pmcm_addlocallistener-admin.log -m akana.container --recipe $INSTALL_PATH/recipes/add-local-listener.json  --props $INSTALL_PATH/recipes/$PROPERTY_FILE --home $INSTALL_PATH
echo "**** Local Listeners Added Sucessfully****"
}

#sleep 5

updateJavaOpts() {
echo "**** Update Java Xmx=4096M"
##sed -i 's/JAVA_OPTS="-Xmx2048M"/JAVA_OPTS="-Xmx4096M"/' $INSTALL_PATH/bin/startup.sh
echo "**** Updated Java Xmx=4096M"
}

shutdownContainer() {
echo "**** Shutdown Container ****"
##$INSTALL_PATH/bin/shutdown.sh $CONTAINER_NAME
echo "**** Container Shutdown Successfully ****"
}

#sleep 5

startContainer() {
echo "**** Start Container ****"
##$INSTALL_PATH/bin/startup.sh $CONTAINER_NAME -bg
echo "**** Container Started Successfully ****"
}

#sleep 240

featureInstallation() {
echo "**** Complete Installation & Provisioning ****"
##$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=$LOG_LEVEL -Dorg.slf4j.simpleLogger.logFile=03_pmcm_provision.log -m akana.container --recipe $INSTALL_PATH/recipes/char-2apiplatform-mongo-installprovision.json  --props $INSTALL_PATH/recipes/$PROPERTY_FILE --home $INSTALL_PATH
echo "**** INSTALLATION & PROVISIONING SUCCESSFULL ****"
}

#sleep 30

containerCluster() {
echo "**** Add Container to Cluster ****"
$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=$LOG_LEVEL -Dorg.slf4j.simpleLogger.logFile=04_add-to-cluster.log -m akana.container --recipe $INSTALL_PATH/recipes/add-to-local-cluster.json  --props $INSTALL_PATH/recipes/$PROPERTY_FILE --home $INSTALL_PATH
echo "**** ADDED CONTAINER TO CLUSTER SUCCESSFULLY ****"
}

finalProvisioning() {
echo "**** Final provisioning ****"
##$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=$LOG_LEVEL -Dorg.slf4j.simpleLogger.logFile=05_final-provisioning.log -m akana.container --recipe $INSTALL_PATH/recipes/char-3apiplatform-mongo-finalprovision.json  --props $INSTALL_PATH/recipes/$PROPERTY_FILE --home $INSTALL_PATH
echo "**** PROVISIONING SUCCESSFULL ****"
}

#sleep 5

restartContainer() {
echo "**** Final restart ****"
##$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=$LOG_LEVEL -Dorg.slf4j.simpleLogger.logFile=06_final-restart.log -m akana.container --recipe $INSTALL_PATH/recipes/restart.json  --props $INSTALL_PATH/recipes/$PROPERTY_FILE --home $INSTALL_PATH
echo "**** RESTARTED SUCCESSFULL ****"
}

###
###     Switch Router
###

case "$1" in

all)
    echo "Starting Container Installation"
	createContainer
	sleep 2
	addListener1
        sleep 2
	addListener2
        sleep 2
	updateJavaOpts
        sleep 2
	shutdownContainer
        sleep 2
	startContainer
        sleep 2
	featureInstallation
        sleep 2
	containerCluster
        sleep 2
	finalProvisioning
        sleep 2
	restartContainer
	;;

container)
	createContainer
	;;

listeners)
	addListener1
	addListener2
	;;

java)
	updateJavaOpts
	;;

features)
	featureInstallation
	;;

clustering)
	containerCluster
	;;

final)
	finalProvisioning
	restartContainer
	;;

*)
    echo "do something"
    ;;

esac
