#!/bin/sh
INSTALL_PATH="/opt/akana/charter/esx-sb-10/2019.1.18"
TENANT_PROPERTY_FILE="cm-tenant.properties"

echo "**** Create CM Tenant container ****"
$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=TRACE -Dorg.slf4j.simpleLogger.logFile=create-tenant.log -m akana.container --recipe $INSTALL_PATH/recipes/cm-https-tenant.json --props $INSTALL_PATH/recipes/$TENANT_PROPERTY_FILE --home $INSTALL_PATH
echo "**** CM TENANT CREATED SUCCESSFULLY ****"
