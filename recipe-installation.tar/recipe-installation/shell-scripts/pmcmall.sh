#!/bin/sh
INSTALL_PATH="/opt/akana/charter/esx-sb-10/2019.1.18"
PROPERTY_FILE="1_apiplatform.properties"
LISTENER_PROPERTY_FILE="1_apiplatform-https-listener.properties"
CONTAINER_NAME="charter_pm"
LOG_LEVEL="TRACE"

echo "**** Create PM Container ****"
$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=$LOG_LEVEL -Dorg.slf4j.simpleLogger.logFile=pmcm.log -m akana.container --recipe $INSTALL_PATH/recipes/pm-cm-mongo.json  --props $INSTALL_PATH/recipes/$PROPERTY_FILE --home $INSTALL_PATH
echo "**** PM CONTAINER CREATED SUCCESSFULLY ****"
