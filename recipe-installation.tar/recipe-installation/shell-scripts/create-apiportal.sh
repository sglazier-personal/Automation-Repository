#!/bin/sh
INSTALL_PATH="/opt/akana/charter/esx-sb-10/2019.1.18"
CM_PROPERTY_FILE="2_apiportal.properties"
CM_LISTENER_PROPERTY_FILE="2_apiportal-https-listener.properties"
CONTAINER_NAME="charter_cm"

echo "**** Create CM container ****"
$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=TRACE -Dorg.slf4j.simpleLogger.logFile=01_cm_create.log -m akana.container --recipe $INSTALL_PATH/recipes/char-5apiportal-mongo-create.json --props $INSTALL_PATH/recipes/$CM_PROPERTY_FILE --home $INSTALL_PATH
echo "**** CM CONTAINER CREATED SUCCESSFULLY ****"

sleep 10

echo "**** Add Container Listeners****"
$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=TRACE -Dorg.slf4j.simpleLogger.logFile=02_cm_addlocallistener-https.log -m akana.container --recipe $INSTALL_PATH/recipes/add-local-listener.json  --props $INSTALL_PATH/recipes/$CM_LISTENER_PROPERTY_FILE --home $INSTALL_PATH

sleep 5

$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=TRACE -Dorg.slf4j.simpleLogger.logFile=02_cm_addlocallistener-admin.log -m akana.container --recipe $INSTALL_PATH/recipes/add-local-listener.json  --props $INSTALL_PATH/recipes/$CM_PROPERTY_FILE --home $INSTALL_PATH
echo "**** HTTPS Listeners ADDED SUCCESSFULLY****"

sleep 10

echo "**** Update Java Xmx=4096M"
sed -i 's/JAVA_OPTS="-Xmx2048M"/JAVA_OPTS="-Xmx4096M"/' $INSTALL_PATH/bin/startup.sh
echo "**** Updated Java Xmx=4096M"

echo "**** Shutdown Container ****"
$INSTALL_PATH/bin/shutdown.sh $CONTAINER_NAME
echo "**** Container Shutdown Successfully ****"

sleep 10

echo "**** Start Container ****"
$INSTALL_PATH/bin/startup.sh $CONTAINER_NAME -bg
echo "**** Container Started Successfully ****"

sleep 60

echo "**** Complete Installation & Provisioning ****"
$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=TRACE -Dorg.slf4j.simpleLogger.logFile=03_cm_provision.log -m akana.container --recipe $INSTALL_PATH/recipes/char-6apiportal-mongo-installprovision.json --props $INSTALL_PATH/recipes/$CM_PROPERTY_FILE --home $INSTALL_PATH

sleep 30

$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=TRACE -Dorg.slf4j.simpleLogger.logFile=03_cm_provision-lr.log -m akana.container --recipe $INSTALL_PATH/recipes/char-6apiportal-mongo-lr.json --props $INSTALL_PATH/recipes/$CM_PROPERTY_FILE --home $INSTALL_PATH
echo "**** INSTALLATION & PROVISIONING SUCCESSFULL ****"

sleep 30

echo "**** Add Container to Cluster ****"
$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=TRACE -Dorg.slf4j.simpleLogger.logFile=04_add-to-cluster.log -m akana.container --recipe $INSTALL_PATH/recipes/add-to-local-cluster.json  --props $INSTALL_PATH/recipes/$CM_PROPERTY_FILE --home $INSTALL_PATH
echo "**** ADDED CONTAINER TO CLUSTER SUCCESSFULLY ****"

sleep 10

echo "**** Final Provisioning ****"
$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=TRACE -Dorg.slf4j.simpleLogger.logFile=05_final-provisioning.log -m akana.container --recipe $INSTALL_PATH/recipes/char-7apiportal-mongo-finalprovision.json --props $INSTALL_PATH/recipes/$CM_PROPERTY_FILE --home $INSTALL_PATH
echo "**** PROVISIONING SUCCESSFULL ****"

sleep 10

echo "**** Final restart ****"
$INSTALL_PATH/bin/jython.sh -Dorg.slf4j.simpleLogger.defaultLogLevel=TRACE -Dorg.slf4j.simpleLogger.logFile=06_final-restart.log -m akana.container --recipe $INSTALL_PATH/recipes/restart.json  --props $INSTALL_PATH/recipes/$CM_PROPERTY_FILE --home $INSTALL_PATH
echo "**** RESTARTED SUCCESSFULL ****"
echo "**** CONTAINER BUILT SUCCESSFULL ****"
