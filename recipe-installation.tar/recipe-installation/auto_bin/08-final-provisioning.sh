#!/bin/bash

./jython.sh -Dorg.slf4j.simpleLogger.logFile=08final.log -m akana.container --recipe ../recipes/final-provision.json --props pmcm.props
