#!/bin/bash

./jython.sh -Dorg.slf4j.simpleLogger.logFile=pmcm.log -m akana.container --recipe ../recipes/pm-cm-all.json --props pmcm.props
